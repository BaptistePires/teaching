#ifndef _INCLUDE_INTERCEPT_H_
#define _INCLUDE_INTERCEPT_H_

void setup_interception(void);

#endif
